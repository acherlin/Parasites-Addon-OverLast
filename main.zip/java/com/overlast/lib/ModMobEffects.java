package com.overlast.lib;


import com.overlast.mobeffect.*;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.potion.Potion;
import net.minecraft.util.math.MathHelper;

public class  ModMobEffects {
	public static final Potion PARASITESPURIFY = new MobEffectParasitesPurify();
	public static final Potion PARASITESINFECT = new MobEffectParasitesInfect();
	public static final Potion FORTUNATE = new MobEffectFortunate();
}
